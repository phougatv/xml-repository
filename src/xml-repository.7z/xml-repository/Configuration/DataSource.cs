﻿namespace XmlRepository.Configuration
{
    public class DataSource
    {
        public Xml Xml { get; set; }
    }
}
