﻿namespace XmlRepository.Configuration
{
    public class Xml
    {
        public string FilePath { get; set; }
        public string FileName { get; set; }
    }
}
